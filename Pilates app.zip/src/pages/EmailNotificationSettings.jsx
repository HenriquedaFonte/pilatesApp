import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import {
  Activity,
  LogOut,
  ArrowLeft,
  Mail,
  Send,
  Settings,
  Users,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Play,
  BarChart3
} from 'lucide-react'

const EmailNotificationSettings = () => {
  const { profile, signOut } = useAuth()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  
  // // Notification settings
  // const [globalSettings, setGlobalSettings] = useState({
  //   enabled: true,
  //   defaultThreshold: 5,
  //   defaultFrequency: 'weekly'
  // })
  
  // Students data
  const [students, setStudents] = useState([])
  const [eligibleStudents, setEligibleStudents] = useState([])
  
  // Email logs
  const [emailLogs, setEmailLogs] = useState([])
  const [emailStats, setEmailStats] = useState({})
  
  // Test mode
  const [testMode, setTestMode] = useState(true)

  useEffect(() => {
    fetchStudents()
    fetchEligibleStudents()
    fetchEmailLogs()
    fetchEmailStats()
  }, [])

  const fetchStudents = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email, email_notifications_enabled, low_credits_threshold, notification_frequency, individual_credits, duo_credits, group_credits')
        .eq('role', 'student')
        .order('full_name')

      if (error) throw error
      setStudents(data || [])
    } catch (error) {
      setError('Error fetching students: ' + error.message)
    }
  }

  const fetchEligibleStudents = async () => {
    try {
      const { data, error } = await supabase.rpc('get_students_for_notification', {
        notification_type: 'low_credits'
      })

      if (error) throw error
      setEligibleStudents(data || [])
    } catch (error) {
      setError('Error fetching eligible students: ' + error.message)
    }
  }

  const fetchEmailLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('email_logs')
        .select('*, profiles(full_name)')
        .order('sent_at', { ascending: false })
        .limit(50)

      if (error) throw error
      setEmailLogs(data || [])
    } catch (error) {
      setError('Error fetching email logs: ' + error.message)
    }
  }

  const fetchEmailStats = async () => {
    try {
      const { data, error } = await supabase.rpc('get_email_notification_stats')

      if (error) throw error
      if (data && data.length > 0) {
        setEmailStats(data[0])
      }
    } catch (error) {
      setError('Error fetching email stats: ' + error.message)
    }
  }

  const updateStudentNotificationSettings = async (studentId, settings) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update(settings)
        .eq('id', studentId)

      if (error) throw error
      
      setSuccess('Student notification settings updated successfully')
      fetchStudents()
    } catch (error) {
      setError('Error updating student settings: ' + error.message)
    }
  }

  const triggerNotifications = async (notificationType) => {
    setLoading(true)
    setError('')
    setSuccess('')

    try {
      const { data, error } = await supabase.functions.invoke('send-low-credits-notifications', {
        body: {
          notification_type: notificationType,
          test_mode: testMode
        }
      })

      if (error) throw error

      setSuccess(`${testMode ? 'Test' : 'Actual'} notifications triggered successfully: ${data.message}`)
      
      // Refresh data
      fetchEmailLogs()
      fetchEmailStats()
      fetchEligibleStudents()
    } catch (error) {
      setError('Error triggering notifications: ' + error.message)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'sent':
      case 'delivered':
        return <Badge variant="default">Sent</Badge>
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>
      case 'bounced':
        return <Badge variant="secondary">Bounced</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('pt-BR')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link to="/teacher/dashboard" className="mr-4">
                <ArrowLeft className="h-6 w-6 text-gray-600 hover:text-gray-900" />
              </Link>
              <Activity className="h-8 w-8 text-primary mr-3" />
              <h1 className="text-xl font-semibold text-gray-900">Email Notifications</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-700">Welcome, {profile?.full_name}</span>
              <Button variant="outline" size="sm" onClick={signOut}>
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Alerts */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {success && (
          <Alert className="mb-6">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Mail className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Emails</p>
                  <p className="text-2xl font-bold text-gray-900">{emailStats.total_emails_sent || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Success Rate</p>
                  <p className="text-2xl font-bold text-gray-900">{emailStats.success_rate || 0}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <AlertTriangle className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Eligible Students</p>
                  <p className="text-2xl font-bold text-gray-900">{eligibleStudents.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Students</p>
                  <p className="text-2xl font-bold text-gray-900">{students.filter(s => s.email_notifications_enabled).length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="trigger" className="space-y-4">
          <TabsList>
            <TabsTrigger value="trigger">
              <Send className="h-4 w-4 mr-2" />
              Trigger Notifications
            </TabsTrigger>
            <TabsTrigger value="students">
              <Users className="h-4 w-4 mr-2" />
              Student Settings
            </TabsTrigger>
            <TabsTrigger value="logs">
              <BarChart3 className="h-4 w-4 mr-2" />
              Email Logs
            </TabsTrigger>
          </TabsList>

          {/* Trigger Notifications Tab */}
          <TabsContent value="trigger">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Trigger Controls */}
              <Card>
                <CardHeader>
                  <CardTitle>Send Notifications</CardTitle>
                  <CardDescription>
                    Manually trigger email notifications for students with low credits
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="test-mode"
                      checked={testMode}
                      onCheckedChange={setTestMode}
                    />
                    <Label htmlFor="test-mode">Test Mode (no actual emails sent)</Label>
                  </div>
                  
                  <div className="space-y-2">
                    <Button
                      onClick={() => triggerNotifications('low_credits')}
                      disabled={loading}
                      className="w-full"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      {loading ? 'Sending...' : 'Send Low Credits Notifications'}
                    </Button>
                    
                    <Button
                      onClick={() => triggerNotifications('zero_credits')}
                      disabled={loading}
                      variant="destructive"
                      className="w-full"
                    >
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      {loading ? 'Sending...' : 'Send Zero Credits Notifications'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Eligible Students Preview */}
              <Card>
                <CardHeader>
                  <CardTitle>Eligible Students</CardTitle>
                  <CardDescription>
                    Students who would receive notifications
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {eligibleStudents.length > 0 ? (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {eligibleStudents.map((student) => (
                        <div key={student.student_id} className="flex justify-between items-center p-2 border rounded">
                          <div>
                            <div className="font-medium">{student.student_name}</div>
                            <div className="text-sm text-gray-500">
                              Total Credits: {student.total_credits}
                            </div>
                          </div>
                          <Badge variant={student.total_credits === 0 ? 'destructive' : 'secondary'}>
                            {student.total_credits === 0 ? 'Zero Credits' : 'Low Credits'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center py-4">No students eligible for notifications</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Student Settings Tab */}
          <TabsContent value="students">
            <Card>
              <CardHeader>
                <CardTitle>Student Notification Settings</CardTitle>
                <CardDescription>
                  Configure individual notification preferences for each student
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Credits</TableHead>
                        <TableHead>Notifications</TableHead>
                        <TableHead>Threshold</TableHead>
                        <TableHead>Frequency</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {students.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{student.full_name}</div>
                              <div className="text-sm text-gray-500">{student.email}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              I: {student.individual_credits || 0} | 
                              D: {student.duo_credits || 0} | 
                              G: {student.group_credits || 0}
                            </div>
                            <div className="font-medium">
                              Total: {(student.individual_credits || 0) + (student.duo_credits || 0) + (student.group_credits || 0)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={student.email_notifications_enabled}
                              onCheckedChange={(enabled) => 
                                updateStudentNotificationSettings(student.id, { email_notifications_enabled: enabled })
                              }
                            />
                          </TableCell>
                          <TableCell>
                            <Input
                              type="number"
                              value={student.low_credits_threshold || 5}
                              onChange={(e) => 
                                updateStudentNotificationSettings(student.id, { low_credits_threshold: parseInt(e.target.value) })
                              }
                              className="w-20"
                            />
                          </TableCell>
                          <TableCell>
                            <Select
                              value={student.notification_frequency || 'weekly'}
                              onValueChange={(frequency) => 
                                updateStudentNotificationSettings(student.id, { notification_frequency: frequency })
                              }
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="daily">Daily</SelectItem>
                                <SelectItem value="weekly">Weekly</SelectItem>
                                <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                <SelectItem value="monthly">Monthly</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Email Logs Tab */}
          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle>Email Notification Logs</CardTitle>
                <CardDescription>
                  Recent email notification activity and status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Student</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Subject</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {emailLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell>{formatDate(log.sent_at)}</TableCell>
                          <TableCell>
                            {log.profiles ? log.profiles.full_name : log.recipient_email}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{log.email_type}</Badge>
                          </TableCell>
                          <TableCell>{getStatusBadge(log.status)}</TableCell>
                          <TableCell className="max-w-xs truncate">{log.subject}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {emailLogs.length === 0 && (
                  <p className="text-gray-500 text-center py-4">No email logs found</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default EmailNotificationSettings

